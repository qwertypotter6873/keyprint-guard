"""
Password 1:1 — is the deployed decision threshold still right on a password the user chose?

The web scores a password attempt with AS-Norm against cohort centroids of CMU subjects typing
`.tie5Roanl`, and accepts it above a threshold calibrated on CMU validation people. A user's own
password is different content, so this script checks how well that calibration transfers, for
the deployed 9-channel password encoder, on keyboard and simulated touch (holds unknown):

  * cmu_*            the CMU password itself (val / test people, cross-session genuine queries)
  * krfixed_*        KeyRecs fixed text `vpwjkeurkb`, enrolled on day 1, verified on day 2
  * words_*_val_* / words_same_day_* / words_cross_day_*
                     words unseen people typed repeatedly in free text (`things`, `people`,
                     `because`): content never trained as a password; evaluated strictly disjointly
                     on Validation (`kr["val"]`) and Test (`kr["test"]`, never pooling val + test).

Decision rules compared (all calibrated strictly on Validation):
  * as_norm   — previous rule: AS-Norm (9ch) >= calibrated_threshold(_touch) from CMU validation
  * raw       — 9ch template similarity (no cohort) >= a threshold tuned on CMU val (max macro-F1)
  * dual      — deployed rule: 9ch + 17ch template similarities standardised and summed, >= tau
                (password_dual in model_config.json, calibrated by the pipeline on many strings
                typed by Validation people; see src/password_synth.py). No template adaptation here;
                its effect is in evaluation_report.json -> feature_upgrade.password_adaptation.

Prints a table and writes models/password_calibration.json.

    python src/eval_password_calibration.py
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import f1_score, roc_auc_score, roc_curve

sys.path.insert(0, str(Path(__file__).resolve().parent))

from behavior_profile import kind_of, load_keyrecs_sessions  # noqa: E402
from capture_sim import make_template, ms_rounded  # noqa: E402
from evaluation_protocol import balanced_impostor_indices
from feature_eval import encode_variable, flat_to_hdu  # noqa: E402
from keyboard_layout import code_for_label, key_channel_matrix, pairs_from_codes  # noqa: E402
from models import KeyPrintNet  # noqa: E402
from password_synth import password_rng
from preprocessing import (  # noqa: E402
    KEYRECS_FIXED_KEY_BLOCK,
    N_TIMING_CHANNELS,
    SEED,
    apply_channel_scaler,
    extract_sequences,
    prepare_full_pipeline,
    read_keyrecs_fixed_timings,
    touchify_timings,
)
from train_and_evaluate import TEST_BOT_SEED, build_verification_trials, compute_cohort_centroids, encode_sequences  # noqa: E402

L9 = N_TIMING_CHANNELS
TOP_M = 12
MODES = ("kb", "touch")


def build_scenarios(data_root: Path, out_root: Path, device, which: str = "9") -> tuple[dict, dict]:
    """Trial groups (enroll embeddings, genuine embeddings, impostor embeddings) per scenario."""
    with tempfile.TemporaryDirectory() as tmp:  # keep data/processed untouched
        splits, meta = prepare_full_pipeline(
            data_root / "data" / "raw" / "DSL-StrongPasswordData.csv", Path(tmp), seed=SEED
        )
    kr = meta["_keyrecs_splits_subjs"]
    mean = np.array(meta["channel_mean"], dtype=np.float32)
    std = np.array(meta["channel_std"], dtype=np.float32)
    bounds = {k: tuple(v) for k, v in meta["outlier_bounds"].items()}
    touch_hold = float(meta["touch_hold_impute_sec"])

    IN = L9 if which == "9" else 17
    model = KeyPrintNet(in_channels=IN, hidden_channels=80, embed_dim=64, dropout=0.18)
    weights = (
        out_root / "models" / "legacy" / "keyprint_net_9ch.pt"
        if which == "9"
        else out_root / "models" / "keyprint_net.pt"
    )
    model.load_state_dict(torch.load(weights, map_location="cpu", weights_only=True))
    model.to(device).eval()

    def seqs(raw_h: np.ndarray, raw_d: np.ndarray, kb: np.ndarray, touch: bool, raw_u: np.ndarray | None = None) -> np.ndarray:
        raw_h = np.asarray(raw_h, dtype=np.float32)
        raw_d = np.asarray(raw_d, dtype=np.float32)
        c_d = np.clip(raw_d, *bounds["DD"]).astype(np.float32)
        if touch:
            h2, u2 = touchify_timings(raw_h, raw_d, touch_hold, bounds)
            return apply_channel_scaler(
                extract_sequences(h2, c_d, u2, kb, np.zeros(len(c_d), dtype=np.float32)),
                mean,
                std,
            )
        u_unclipped = (raw_d - raw_h[:, :-1]) if raw_u is None else np.asarray(raw_u, dtype=np.float32)
        c_h = np.clip(raw_h, *bounds["H"]).astype(np.float32)
        c_u = np.clip(u_unclipped, *bounds["UD"]).astype(np.float32)
        return apply_channel_scaler(extract_sequences(c_h, c_d, c_u, kb), mean, std)

    tr_h, tr_d = splits["train"].raw_holds, splits["train"].raw_dds
    cohorts = {
        "kb": compute_cohort_centroids(
            encode_sequences(model, splits["train"].seq_scaled[:, :IN], device), splits["train"].subject_ids
        ),
        "touch": compute_cohort_centroids(
            encode_sequences(model, seqs(tr_h, tr_d, splits["train"].key_block, True)[:, :IN], device),
            splits["train"].subject_ids,
        ),
    }
    scen: dict = {}

    # 1) CMU password: the pipeline's trials, first 4 enrollment reps like the web
    for part in ("val", "test"):
        trials = build_verification_trials(splits[part], mean, std, k_shot=5, seed=SEED, bot_seed=TEST_BOT_SEED if part == "test" else None)
        h, d = splits[part].raw_holds, splits[part].raw_dds
        bh, bd = flat_to_hdu(trials["bot_flat"])
        for mode in MODES:
            if mode == "kb":
                emb = encode_sequences(model, splits[part].seq_scaled[:, :IN], device)
                bemb = encode_sequences(model, trials["bot_seq"][:, :IN], device)
            else:
                emb = encode_sequences(model, seqs(h, d, splits[part].key_block, True)[:, :IN], device)
                bemb = encode_sequences(
                    model, seqs(bh.astype(np.float32), bd.astype(np.float32), splits[part].key_block, True)[:, :IN], device
                )
            scen[f"cmu_{part}_{mode}"] = [
                (emb[g["enroll_idx"][:4]], emb[g["gen_idx"]], np.concatenate([emb[g["imp_idx"]], bemb[g["bot_idx"]]]))
                for g in trials["groups"]
            ]

    # 2) KeyRecs fixed text: enroll 4 reps on day 1, genuine = day 2, impostors = 10 day-2 reps of each other person
    fixed_path = data_root / "data" / "raw" / "KeyRecs-fixed-text.csv"
    fixed_interpretation = meta["keyrecs_fixed_timestamps"]["selected_interpretation"]
    for part in ("val", "test"):
        rng = password_rng(SEED, part, "fixed_comparison_queries")
        sub, raw_h, raw_d, raw_u = read_keyrecs_fixed_timings(fixed_path, kr[part], fixed_interpretation)
        P, S = sub["participant"].values, sub["session"].values
        imp_pick = {}
        for p in np.unique(P):
            imp = []
            for q in np.unique(P):
                if q != p:
                    cand = np.where((P == q) & (S == 2))[0]
                    imp.extend(rng.choice(cand, size=min(10, len(cand)), replace=False).tolist())
            imp_pick[p] = imp
        for mode in MODES:
            tensors = seqs(raw_h, raw_d, KEYRECS_FIXED_KEY_BLOCK, mode == "touch", raw_u)
            emb = encode_variable(model, list(tensors), device, IN)
            groups = []
            for p in np.unique(P):
                own = np.where(P == p)[0]
                enroll, gen = own[S[own] == 1][:4], own[S[own] == 2]
                if len(enroll) == 4 and len(gen):
                    groups.append((emb[enroll], emb[gen], emb[imp_pick[p]]))
            scen[f"krfixed_{part}_{mode}"] = groups

    # 3) Repeated words of unseen people — strictly separated between kr["val"] and kr["test"] (never pooled!)
    raw_sessions = {
        k: ms_rounded(v) for k, v in load_keyrecs_sessions(data_root / "data" / "raw" / "KeyRecs-free-text.csv").items()
    }
    words_by_part: dict[str, list[str]] = {"val": [], "test": []}
    for part in ("val", "test"):
        occ = defaultdict(lambda: defaultdict(lambda: {1: [], 2: []}))
        for p in kr[part]:
            for s in (1, 2):
                cur, ok = [], True
                for label, t, hold in list(raw_sessions.get((p, s), [])) + [("Space", 1e12, 0.1)]:
                    kind, _ = kind_of(label)
                    if kind == "space":
                        if ok and len(cur) >= 5:
                            ts = np.array([c[1] for c in cur])
                            hs = np.array([c[2] for c in cur])
                            dd = np.diff(ts)
                            if not ((dd <= 0.006).any() or (dd > 2.2).any() or (hs > 1.2).any() or (hs < 0.008).any()):
                                occ["".join(c[0] for c in cur)][p][s].append((hs, dd))
                        cur, ok = [], True
                    elif kind == "char" and len(label) == 1 and label.isalpha():
                        cur.append((label.lower(), t, hold))
                    elif kind in ("shift", "caps"):
                        continue
                    else:
                        ok = False

        for mode in MODES:
            same, cross = [], []
            for w, per in occ.items():
                enrolled = [p for p, v in per.items() if len(v[1]) >= 3 and len(v[1]) + len(v[2]) >= 4]
                if len(enrolled) < 3 or len(per) < 4:
                    continue
                kbm = key_channel_matrix(pairs_from_codes([code_for_label(c) for c in w]))
                tensors, index = [], {}
                for p, v in per.items():
                    for s in (1, 2):
                        for k, (hs, dd) in enumerate(v[s]):
                            raw_hh = np.asarray(hs, dtype=np.float32)[None]
                            raw_dc = np.asarray(dd, dtype=np.float32)[None]
                            tensors.append(seqs(raw_hh, raw_dc, kbm[None], mode == "touch")[0])
                            index[(p, s, k)] = len(tensors) - 1
                emb = encode_variable(model, tensors, device, IN)
                for p in enrolled:
                    s1 = [index[(p, 1, k)] for k in range(len(per[p][1]))]
                    s2 = [index[(p, 2, k)] for k in range(len(per[p][2]))]
                    imp = balanced_impostor_indices(index, p, w, seed=SEED)
                    if s1[3:] and imp:
                        same.append((emb[s1[:3]], emb[s1[3:]], emb[imp]))
                    if s2 and imp:
                        cross.append((emb[s1[:3]], emb[s2], emb[imp]))
                if mode == "kb":
                    words_by_part[part].append(w)
            if part == "val":
                if same:
                    scen[f"words_same_day_val_{mode}"] = same
                if cross:
                    scen[f"words_cross_day_val_{mode}"] = cross
            else:
                if same:
                    scen[f"words_same_day_{mode}"] = same
                if cross:
                    scen[f"words_cross_day_{mode}"] = cross

    return scen, {
        "cohorts": cohorts, "words": words_by_part["test"], "words_val": words_by_part["val"],
        "keyrecs_fixed_timestamp_interpretation": fixed_interpretation,
    }


def score(groups, cohort):
    """Labels, deployed AS-Norm scores and raw template similarities (same formula as the web)."""
    y, a, r = [], [], []
    for E, G, I in groups:
        tmpl = make_template(np.asarray(E, dtype=np.float64))
        u = np.sort(cohort @ tmpl["centroid"])[-TOP_M:]
        for Q, lab in ((G, 1), (I, 0)):
            Q = np.asarray(Q, dtype=np.float64)
            raw = 0.65 * (Q @ tmpl["centroid"]) + 0.35 * np.max(Q @ tmpl["exemplars"].T, axis=1)
            q = np.sort(Q @ cohort.T, axis=1)[:, -TOP_M:]
            z = (raw - 0.5 * (u.mean() + q.mean(1))) / (0.5 * (u.std() + 0.05 + q.std(1) + 0.05))
            a += list(1.0 / (1.0 + np.exp(-0.85 * (z - 0.15))))
            r += list(raw)
            y += [lab] * len(Q)
    return np.asarray(y), np.asarray(a), np.asarray(r)


def f1_threshold(y, s):
    cand = np.linspace(np.percentile(s, 5), np.percentile(s, 95), 300)
    return float(cand[int(np.argmax([f1_score(y, (s >= t).astype(int), average="macro") for t in cand]))])


def rates(y, s, thr):
    far = float((s[y == 0] >= thr).mean())
    frr = float((s[y == 1] < thr).mean())
    return {"far": round(far, 4), "frr": round(frr, 4), "hter": round((far + frr) / 2, 4)}


def eer_point(y, s):
    fpr, tpr, thr = roc_curve(y, s)
    i = int(np.argmin(np.abs(fpr - (1 - tpr))))
    return round(float((fpr[i] + 1 - tpr[i]) / 2), 4), round(float(thr[i]), 4)


def main() -> None:
    data_root = Path(__file__).resolve().parent.parent
    out_root = Path(os.environ["KEYPRINT_OUTPUT_ROOT"]).resolve() if os.environ.get("KEYPRINT_OUTPUT_ROOT") else data_root
    device = torch.device("cpu")
    cfg = json.loads((out_root / "web" / "public" / "models" / "model_config.json").read_text(encoding="utf-8"))
    deployed = {"kb": float(cfg["calibrated_threshold"]), "touch": float(cfg["calibrated_threshold_touch"])}
    dual = cfg["password_dual"]
    dual_prm = {"kb": dual["keyboard"], "touch": dual["touch"]}

    scen9, info = build_scenarios(data_root, out_root, device, "9")
    scen17, _ = build_scenarios(data_root, out_root, device, "17")
    scored = {}
    for k in scen9:
        mode = "touch" if k.endswith("touch") else "kb"
        y, a, r = score(scen9[k], info["cohorts"][mode])
        _, _, r17 = score(scen17[k], info["cohorts"][mode])  # cohort unused for raw17
        p = dual_prm[mode]
        scored[k] = (y, a, r, (r - p["mu9"]) / p["sd9"] + (r17 - p["mu17"]) / p["sd17"])
    raw_thr = {m: f1_threshold(scored[f"cmu_val_{m}"][0], scored[f"cmu_val_{m}"][2]) for m in MODES}

    out = {
        "as_norm_threshold": deployed,
        "raw_threshold_cmu_val": {m: round(v, 4) for m, v in raw_thr.items()},
        "dual": dual_prm,
        "words": info["words"],
        "words_val": info["words_val"],
        "keyrecs_fixed_timestamp_interpretation": info["keyrecs_fixed_timestamp_interpretation"],
        "split_isolation": {
            "val_test_pooled": False,
            "calibration_splits": ["cmu_val", "keyrecs_val"],
        },
        "scenarios": {},
    }
    print(
        f"AS-Norm thresholds {deployed} | raw thresholds (CMU val) {out['raw_threshold_cmu_val']} | dual tau "
        f"{ {m: p['tau'] for m, p in dual_prm.items()} }"
    )
    print(
        f"{'scenario':24s} {'gen/imp':>10s} | {'AS-Norm AUC  FAR / FRR':>24s} | "
        f"{'raw FAR / FRR':>15s} | {'dual AUC  FAR / FRR':>21s}"
    )
    for k, (y, a, r, z) in scored.items():
        m = "touch" if k.endswith("touch") else "kb"
        eer, eer_thr = eer_point(y, a)
        dep, raw, du = rates(y, a, deployed[m]), rates(y, r, raw_thr[m]), rates(y, z, dual_prm[m]["tau"])
        out["scenarios"][k] = {
            "num_genuine": int((y == 1).sum()),
            "num_impostor": int((y == 0).sum()),
            "as_norm_auc": round(float(roc_auc_score(y, a)), 4),
            "as_norm_eer": eer,
            "as_norm_eer_threshold": eer_thr,
            "raw_auc": round(float(roc_auc_score(y, r)), 4),
            "dual_auc": round(float(roc_auc_score(y, z)), 4),
            "as_norm": dep,
            "raw_cmu_val_threshold": raw,
            "dual": du,
        }
        print(
            f"{k:24s} {int((y == 1).sum()):4d}/{int((y == 0).sum()):<5d} | "
            f"{out['scenarios'][k]['as_norm_auc']:.3f} {dep['far'] * 100:6.1f} / {dep['frr'] * 100:5.1f}% | "
            f"{raw['far'] * 100:5.1f} / {raw['frr'] * 100:5.1f}% | "
            f"{out['scenarios'][k]['dual_auc']:.3f} {du['far'] * 100:5.1f} / {du['frr'] * 100:5.1f}%"
        )
    path = out_root / "models" / "password_calibration.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"wrote {path}")


if __name__ == "__main__":
    main()
